/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ulima.eda.colas;

import edu.ulima.eda.listas.dobles.ListaEnlazadaDoble;
/**
 *
 * @author JC
 */
public class Cola<T>{
    ListaEnlazadaDoble<T> lista;
    
    public Cola(){
        lista = new ListaEnlazadaDoble();
    }
    
    public boolean estaVacia(){
        return (lista.getI() == null && lista.getF() == null);
    }
    public void encolar(T dato){
        lista.insertarAlFinal(dato);
    }
    
    public T desencolar(){
        T respuesta = null;
        if(!this.estaVacia()){
            respuesta = (T)lista.getI().info;
            lista.eliminarPrimero();
        }
        return respuesta;
    }
    
    public void mostrarElementos(){
        String datos="";
        System.out.print("frente -> ");
        lista.mostrar();
        
    } 
    
}

