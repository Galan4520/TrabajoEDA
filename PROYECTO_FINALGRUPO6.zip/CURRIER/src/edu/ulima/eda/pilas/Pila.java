package edu.ulima.eda.pilas;

import Mclase.Comprobante;
import edu.ulima.eda.listas.ListaEnlazada;

/**
 *
 * @author JC
 */
public class Pila<T>{
    private ListaEnlazada<T> lista;
    
    public Pila(){
        lista = new ListaEnlazada<>();
    }
    
    public boolean estaVacia(){
        return (lista.getL() == null);
    }
    
    public void apilar(T valor){
        lista.insertarAlInicio(valor);
    }
    
    public T desapilar(){
        T respuesta = null;
        if(lista.getL() != null){
            respuesta = (T) lista.getL().info();
            lista.eliminarInicio();    
        }
        return respuesta;
    }
    
    public void mostrarElementos(){
        System.out.print("cima --> ");
        lista.mostrarElementos();
        
    }
}
